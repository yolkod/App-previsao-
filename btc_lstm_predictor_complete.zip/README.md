# BTC Predictor com LSTM e Índice de Medo e Ganância

Projeto de previsão de alta ou baixa do Bitcoin utilizando LSTM e indicadores técnicos.

## Executar no Streamlit Cloud
- Clone este repositório.
- Acesse [https://streamlit.io/cloud](https://streamlit.io/cloud).
- Suba o projeto e rode o arquivo `app.py`.

## Bibliotecas necessárias
Veja o arquivo `requirements.txt`.